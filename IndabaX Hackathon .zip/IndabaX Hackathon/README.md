Forecasting Botswana's Human Capital Under Global Economic Shocks

IndabaX Botswana 2026 — Deep Learning Hackathon submission

Overview

This project forecasts Botswana's monthly food price inflation 12 months ahead
(Jan–Dec 2024), using two models — a classical baseline and a deep learning
model — as required by the hackathon's two-model rule. It also quantifies the
link between Botswana's food inflation and regional (South Africa, Namibia)
food inflation as a proxy human-capital-linkage indicator.

Key finding: Botswana's food inflation is highly persistent
("sticky") — once a shock pushes prices up, they stay elevated for months.
The Random Forest baseline (MAE 1.10%) substantially outperformed the MLP deep
learning model (MAE 5.11%) on 2023 holdout data, because the dataset is small
(~264 monthly rows) and the dominant signal is simple autoregressive
persistence, which tree models capture more efficiently than a neural network
can learn from this little data.

Project structure

.
├── README.md
├── requirements.txt
├── data/
│   ├── 01_baltic_dry_index_daily.csv
│   ├── 02_brent_crude_monthly.csv
│   ├── 03_botswana_policy_rate.csv
│   ├── 04_fao_botswana_prices.csv
│   └── 05_human_capital_project.csv
├── classical_model/
│   └── random_forest_model.py
├── deep_learning_model/
│   └── mlp_model.py
├── hcp_linkage/
│   └── hcp_analysis.py          # Granger causality + regression (HCP memo)
├── notebooks/
│   └── 00_DATA_GUIDE.py         # data exploration / merge walkthrough
└── outputs/
    ├── predictions_2024.csv     # final submission (Random Forest, best model)
    ├── hcp_historical_comovement.png
    └── hcp_forward_projection.png

Setup
pip install -r requirements.txt


Data

The 5 raw datasets (Baltic Dry Index, Brent crude, Botswana policy rate, FAO
Botswana prices, and the regional Human Capital Project file) all end at
December 2023. Place them in `data/` before running any script — if the repo
size limit is an issue, a Google Drive link to the datasets can go here
instead.

Feature engineering (summary)

- Baltic Dry Index (daily) resampled to monthly mean
- Brent crude and policy rate aligned to month-start
- FAO Botswana prices pivoted into `CPI_General`, `CPI_Food`, `Food_Inflation` (target)
- Regional HCP file filtered to South Africa, Namibia, Kenya, Zimbabwe to build
  a `Regional_Food_Inflation_Avg` feature (cross-border spillover)
- Lag features at 1, 2, 3, 6, and 12 months; rolling 3- and 6-month windows
- Final merged dataset: 264 monthly observations (Jan 2002 – Dec 2023)

Since all data ends Dec 2023, 2024 exogenous features (Brent, BDI) are held at
their recent late-2023 averages during the forecast — no phantom future
features are used.

Model 1 — Classical baseline: Random Forest

python classical_model/random_forest_model.py


- 100 estimators, max depth 5 (limits overfitting on the small dataset)
- Recursive multi-step forecasting: each month's prediction feeds back in as
  next month's `lag_1` feature
- 2023 holdout: **MAE 1.10%, RMSE 1.26%**
- `Food_Inflation_lag_1` accounts for ~95% of feature importance

Model 2 — Deep learning: Multi-Layer Perceptron

python deep_learning_model/mlp_model.py


- 2 hidden layers (32, 16 neurons), ReLU activation, Adam optimizer, early
  stopping
- Direct prediction from scaled lagged features
- 2023 holdout: **MAE 5.11%, RMSE 5.65%**
- Underperforms the Random Forest — with only ~260 rows, the network doesn't
  have enough data to learn the sharp late-2023 downward trend and produces
  overly conservative predictions

  HCP linkage analysis
  
python hcp_linkage/hcp_analysis.py


Granger causality (lags 1–6) and OLS regression showing Botswana's food
inflation is significantly linked to South African and Namibian food
inflation at a 2-month lag (R² = 0.428, both coefficients p < 0.05). See
`outputs/hcp_historical_comovement.png` and
`outputs/hcp_forward_projection.png` for the required visualisations.

Final forecast (2024, Random Forest — best model)

Submitted in `outputs/predictions_2024.csv`, stabilizing around 5.3–5.5% as
the 2023 inflation spike decays, assuming no new global shock.

Reproducing results end-to-end

python classical_model/random_forest_model.py
python deep_learning_model/mlp_model.py
python hcp_linkage/hcp_analysis.py


All three scripts read from `data/` and write their outputs to `outputs/`.
