import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from statsmodels.tsa.stattools import adfuller, grangercausalitytests
import statsmodels.api as sm
import warnings
warnings.filterwarnings('ignore')

# Load all datasets
brent_data = pd.read_csv('02_brent_crude_monthly.csv')
policy_data = pd.read_csv('03_botswana_policy_rate.csv')
bdi_data = pd.read_csv('01_baltic_dry_index_daily .csv')
fao_botswana = pd.read_csv('04_fao_botswana_prices.csv')
fao_regional = pd.read_csv('05_human_capital_project.csv')

# Display basic info
print("=== Data Overview ===")
print(f"Brent Crude: {brent_data.shape}")
print(f"Policy Rate: {policy_data.shape}")
print(f"BDI: {bdi_data.shape}")
print(f"FAO Botswana: {fao_botswana.shape}")
print(f"FAO Regional: {fao_regional.shape}")

# Convert dates
brent_data['Date'] = pd.to_datetime(brent_data['Date'])
policy_data['Date'] = pd.to_datetime(policy_data['Date'])
bdi_data['Date'] = pd.to_datetime(bdi_data['Date'])
fao_botswana['Date'] = pd.to_datetime(fao_botswana['Date'])
fao_regional['Date'] = pd.to_datetime(fao_regional['Date'])

print(brent_data.head())
print(policy_data.head())
print(bdi_data.head())
print(fao_botswana.head())
print(fao_regional.head())


# Extract Botswana food inflation
botswana_inflation = fao_botswana[fao_botswana['Item Code'] == 23014].copy()

botswana_inflation = botswana_inflation[['Date', 'Value']].rename(
    columns={'Value': 'Food_Inflation'}
)

botswana_inflation = botswana_inflation.dropna()

print(f"Botswana Food Inflation: {len(botswana_inflation)} observations")
print(f"Date range: {botswana_inflation['Date'].min()} to {botswana_inflation['Date'].max()}")

print("\nFirst 10 rows:")
print(botswana_inflation.head(10))

# Extract regional food inflation
regional_inflation = fao_regional.loc[
    (fao_regional['INDICATOR'] == 'FAO_CP_23014') &
    (fao_regional['REF_AREA'].isin(['ZAF', 'NAM', 'KEN', 'ZWE']))
].copy()

# Create separate columns for each country
regional_pivot = regional_inflation.pivot_table(
    index='Date',
    columns='REF_AREA',
    values='Value'
).reset_index()

print("Regional Food Inflation Data:")
print(regional_pivot.head())

print("\nMissing values per country:")
print(regional_pivot.isnull().sum())


# Check missing values
print("\nMissing values in Botswana Food Inflation:")
print(botswana_inflation.isnull().sum())

# Basic statistics
print("\nFood Inflation Summary:")
print(botswana_inflation['Food_Inflation'].describe())

# Sort datasets by date
brent_data = brent_data.sort_values('Date')
policy_data = policy_data.sort_values('Date')
bdi_data = bdi_data.sort_values('Date')
botswana_inflation = botswana_inflation.sort_values('Date')

# Merge datasets
combined_data = pd.merge_asof(
    botswana_inflation,
    brent_data,
    on='Date',
    direction='nearest'
)

combined_data = pd.merge_asof(
    combined_data,
    policy_data,
    on='Date',
    direction='nearest'
)

combined_data = pd.merge_asof(
    combined_data,
    bdi_data,
    on='Date',
    direction='nearest'
)

print("\nCombined Dataset:")
print(combined_data.head())

print("\nDataset Shape:")
print(combined_data.shape)


# Perform ADF tests on Botswana, South Africa, and Namibia
def adf_test(series, name):
    series_clean = series.dropna()
    result = adfuller(series_clean)
    print(f"{name}:")
    print(f"  ADF Statistic: {result[0]:.4f}")
    print(f"  p-value: {result[1]:.4f}")
    print(f"  Stationary: {'Yes' if result[1] < 0.05 else 'No'}")
    print(f"  Observations: {len(series_clean)}")
    return result

print("\n=== ADF Stationarity Tests ===")
# Botswana
botswana_series = botswana_inflation.set_index('Date')['Food_Inflation']
adf_test(botswana_series, "Botswana Food Inflation")

# South Africa
south_africa = regional_pivot[['Date', 'ZAF']].dropna().set_index('Date')['ZAF']
adf_test(south_africa, "South Africa Food Inflation")

# Namibia
namibia = regional_pivot[['Date', 'NAM']].dropna().set_index('Date')['NAM']
adf_test(namibia, "Namibia Food Inflation")

# Prepare merged data for Granger causality
merged_granger = botswana_inflation.merge(regional_pivot, on='Date', how='inner')
merged_granger = merged_granger.dropna()
merged_granger = merged_granger.set_index('Date')

print(f"\n=== Granger Causality Tests ===")
print(f"Data range: {merged_granger.index.min()} to {merged_granger.index.max()}")
print(f"Observations: {len(merged_granger)}")

# Test South Africa -> Botswana
def granger_test(data, cause, effect, maxlag=6):
    # Create dataframe with two columns
    df = data[[effect, cause]].dropna()
    
    # Prepare results
    results = []
    for lag in range(1, maxlag + 1):
        if len(df) > lag * 2:
            try:
                test_result = grangercausalitytests(df[effect + cause], maxlag=lag, verbose=False)
                pvalue = test_result[lag][0]['ssr_ftest'][1]
                results.append({'lag': lag, 'pvalue': pvalue, 'significant': pvalue < 0.05})
            except:
                results.append({'lag': lag, 'pvalue': np.nan, 'significant': False})
    
    return pd.DataFrame(results)

# Test South Africa
print("\nSouth Africa -> Botswana Food Inflation:")
sa_results = granger_test(merged_granger, 'ZAF', 'Food_Inflation')
print(sa_results)
best_sa_lag = sa_results[sa_results['significant']]['lag'].min() if sa_results[sa_results['significant']].shape[0] > 0 else None
if best_sa_lag:
    print(f"Best lag (significant): {best_sa_lag}")

# Test Namibia
print("\nNamibia -> Botswana Food Inflation:")
nam_results = granger_test(merged_granger, 'NAM', 'Food_Inflation')
print(nam_results)
best_nam_lag = nam_results[nam_results['significant']]['lag'].min() if nam_results[nam_results['significant']].shape[0] > 0 else None
if best_nam_lag:
    print(f"Best lag (significant): {best_nam_lag}")

   # Prepare merged data for Granger causality
merged_granger = botswana_inflation.merge(regional_pivot, on='Date', how='inner')
merged_granger = merged_granger.dropna()
merged_granger = merged_granger.set_index('Date')

print(f"\n=== Granger Causality Tests ===")
print(f"Data range: {merged_granger.index.min()} to {merged_granger.index.max()}")
print(f"Observations: {len(merged_granger)}")

# Test South Africa -> Botswana
def granger_test(data, cause, effect, maxlag=6):
    # Create dataframe with two columns
    df = data[[effect, cause]].dropna()
    
    # Prepare results
    results = []
    for lag in range(1, maxlag + 1):
        if len(df) > lag * 2:
            try:
                test_result = grangercausalitytests(df[effect + cause], maxlag=lag, verbose=False)
                pvalue = test_result[lag][0]['ssr_ftest'][1]
                results.append({'lag': lag, 'pvalue': pvalue, 'significant': pvalue < 0.05})
            except:
                results.append({'lag': lag, 'pvalue': np.nan, 'significant': False})
    
    return pd.DataFrame(results)

# Test South Africa
print("\nSouth Africa -> Botswana Food Inflation:")
sa_results = granger_test(merged_granger, 'ZAF', 'Food_Inflation')
print(sa_results)
best_sa_lag = sa_results[sa_results['significant']]['lag'].min() if sa_results[sa_results['significant']].shape[0] > 0 else None
if best_sa_lag:
    print(f"Best lag (significant): {best_sa_lag}")

# Test Namibia
print("\nNamibia -> Botswana Food Inflation:")
nam_results = granger_test(merged_granger, 'NAM', 'Food_Inflation')
print(nam_results)
best_nam_lag = nam_results[nam_results['significant']]['lag'].min() if nam_results[nam_results['significant']].shape[0] > 0 else None
if best_nam_lag:
    print(f"Best lag (significant): {best_nam_lag}") 


    import statsmodels.api as sm

# Create lagged variables
merged_ols = merged_granger.copy()
merged_ols['ZAF_lag2'] = merged_ols['ZAF'].shift(2)
merged_ols['NAM_lag2'] = merged_ols['NAM'].shift(2)
merged_ols = merged_ols.dropna()

# Run OLS regression
X = merged_ols[['ZAF_lag2', 'NAM_lag2']]
X = sm.add_constant(X)
y = merged_ols['Food_Inflation']

model = sm.OLS(y, X).fit()
print("\n=== OLS Regression Results (Lag 2) ===")
print(model.summary())

# Compare with document findings
print("\n=== Comparison with Document Findings ===")
print(f"Document - R²: 0.428")
print(f"Actual - R²: {model.rsquared:.3f}")
print(f"Document - ZAF coefficient: 0.439, p-value: 0.001")
print(f"Actual - ZAF coefficient: {model.params['ZAF_lag2']:.3f}, p-value: {model.pvalues['ZAF_lag2']:.4f}")
print(f"Document - NAM coefficient: 0.356, p-value: 0.012")
print(f"Actual - NAM coefficient: {model.params['NAM_lag2']:.3f}, p-value: {model.pvalues['NAM_lag2']:.4f}")

from statsmodels.stats.stattools import durbin_watson

dw_stat = durbin_watson(model.resid)
print(f"\n=== Durbin-Watson Statistic ===")
print(f"Document value: 0.083")
print(f"Actual value: {dw_stat:.3f}")
print(f"Interpretation: Strong positive autocorrelation (DW < 1.5)")

# Plot historical co-movement
fig, axes = plt.subplots(2, 1, figsize=(12, 10))

# Plot 1: Botswana Food Inflation
ax1 = axes[0]
ax1.plot(botswana_inflation['Date'], botswana_inflation['Food_Inflation'], 
         label='Botswana Food Inflation', color='blue', linewidth=2)
ax1.set_title('Botswana Food Price Inflation (2001-2023)', fontsize=14)
ax1.set_ylabel('Inflation (%)', fontsize=12)
ax1.axhline(y=0, color='black', linestyle='-', alpha=0.3)
ax1.grid(True, alpha=0.3)
ax1.legend()

# Plot 2: Regional Comparison
ax2 = axes[1]
ax2.plot(botswana_inflation['Date'], botswana_inflation['Food_Inflation'], 
         label='Botswana', color='blue', linewidth=2)

# Add South Africa and Namibia
sa_nam = regional_pivot[['Date', 'ZAF', 'NAM']].dropna()
sa_nam = sa_nam[sa_nam['Date'] >= botswana_inflation['Date'].min()]
ax2.plot(sa_nam['Date'], sa_nam['ZAF'], label='South Africa', color='green', alpha=0.7)
ax2.plot(sa_nam['Date'], sa_nam['NAM'], label='Namibia', color='orange', alpha=0.7)

ax2.set_title('Regional Food Inflation Comparison', fontsize=14)
ax2.set_ylabel('Inflation (%)', fontsize=12)
ax2.axhline(y=0, color='black', linestyle='-', alpha=0.3)
ax2.grid(True, alpha=0.3)
ax2.legend()

plt.tight_layout()
plt.savefig('food_inflation_trends.png', dpi=150)
plt.show()

print("\n=== Historical Co-Movement Summary ===")
print(f"Botswana Inflation Range: {botswana_inflation['Food_Inflation'].min():.2f}% to {botswana_inflation['Food_Inflation'].max():.2f}%")
print(f"Botswana Current (Dec 2023): {botswana_inflation[botswana_inflation['Date'] == '2023-12-01']['Food_Inflation'].iloc[0]:.4f}%")
print(f"SA Current (Dec 2023): 8.622222%")
print(f"Namibia Current (Dec 2023): 7.411504%")

# 1. Verify BDI resampling
print("\n=== BDI Data Verification ===")
bdi_data['Date'] = pd.to_datetime(bdi_data['Date'])
bdi_monthly = bdi_data.set_index('Date').resample('MS')['BDI_Close'].mean().reset_index()
print(f"BDI Original: {len(bdi_data)} observations")
print(f"BDI Monthly (resampled): {len(bdi_monthly)} observations")
print(f"BDI Date range: {bdi_monthly['Date'].min()} to {bdi_monthly['Date'].max()}")

# 2. Verify Brent data
print("\n=== Brent Crude Data ===")
print(f"Brent Date range: {brent_data['Date'].min()} to {brent_data['Date'].max()}")
print(f"Brent observations: {len(brent_data)}")

# 3. Verify merged dataset size (should be ~264 observations)
print("\n=== Merged Dataset Verification ===")
# Merge Botswana inflation with monthly Brent
merged_all = botswana_inflation.merge(brent_data, on='Date', how='inner')
print(f"After merging with Brent: {len(merged_all)} observations")

# Merge with BDI monthly
merged_all = merged_all.merge(bdi_monthly, on='Date', how='inner')
print(f"After merging with BDI: {len(merged_all)} observations")

# Merge with policy rate
merged_all = merged_all.merge(policy_data, on='Date', how='inner')
print(f"After merging with Policy Rate: {len(merged_all)} observations")

print(f"\nFinal merged dataset: {len(merged_all)} observations")
print(f"Date range: {merged_all['Date'].min()} to {merged_all['Date'].max()}")

# Document claims 264 observations (Jan 2002 - Dec 2023)
expected_start = pd.Timestamp('2002-01-01')
expected_end = pd.Timestamp('2023-12-01')
actual_start = merged_all['Date'].min()
actual_end = merged_all['Date'].max()
print(f"\nExpected start: {expected_start}")
print(f"Actual start: {actual_start}")
print(f"Expected end: {expected_end}")
print(f"Actual end: {actual_end}")
print(f"Observations match expectation: {len(merged_all) == 264}")



# Calculate Regional_Food_Inflation_Avg (South Africa, Namibia, Kenya, Zimbabwe)
regional_cols = ['ZAF', 'NAM', 'KEN', 'ZWE']
regional_pivot['Regional_Avg'] = regional_pivot[regional_cols].mean(axis=1)

print("\n=== Regional Food Inflation Average ===")
print(f"Countries included: South Africa, Namibia, Kenya, Zimbabwe")
print(f"Regional average range: {regional_pivot['Regional_Avg'].min():.2f}% to {regional_pivot['Regional_Avg'].max():.2f}%")
print(f"Latest regional average (Dec 2023): {regional_pivot[regional_pivot['Date'] == '2023-12-01']['Regional_Avg'].iloc[0]:.4f}%")

# Monthly BDI
bdi_monthly = (
    bdi_data.set_index('Date')
    .resample('MS')['BDI_Close']
    .mean()
    .reset_index()
)

plt.figure(figsize=(10,5))
plt.plot(bdi_monthly['Date'], bdi_monthly['BDI_Close'])
plt.title('Monthly Baltic Dry Index')
plt.xlabel('Date')
plt.ylabel('BDI Close')
plt.grid(True)

plt.savefig('monthly_bdi.png', dpi=150)
plt.show()